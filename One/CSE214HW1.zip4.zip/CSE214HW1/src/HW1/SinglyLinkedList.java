package HW1;


import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;


public class SinglyLinkedList<T> implements CSE214List<T>{

    public static class Node<T> {
        T element;
        Node<T> next;
        Node(T element, Node<T> next) {
            this.element = element;
            this.next = next;
        }
        Node(T element) {

            this(element, null);
        }


    }
    private Node<T> first;
    private Node<T> cursor;


    public SinglyLinkedList(){
        first = null;
        //CSE214List<T> emptylist = new SinglyLinkedList<>();

    }

    public SinglyLinkedList(T ... elements){
        first = new Node<T>(elements[0]);
        //System.out.println(first);
        cursor = first;
        Node<T> previous = first;
        for (int i = 1; i < elements.length; i++) {
            Node<T> current = new Node<T>(elements[i]);
            previous.next = current;
            previous = current;
        }
        //CSE214List<T> variablelist = new SinglyLinkedList<>(element);
    }
    public int size(){
        Node<T> temp = first;
        int count = 0;
        while(temp != null){
            temp = temp.next;
            count++;
        }
        return count;
    }
    public void add(T elem, int index){
        if(first == null){
            first = new Node<T>(elem);
        }
        else{
            Node<T> xyz = new Node<T>(elem);
            Node<T> afirst = first;
            int count = 0;
            while(afirst != null){
                afirst = afirst.next;
                count++;
            }
            if(index == 0){
                Node<T> temp = first;
                first = xyz;
                first.next = temp;
            }
            else if(index > count){
                Node<T> temp = first;
                Node<T> newnode = new Node<T>(elem);
                int tempindex = 0;
                while(tempindex < count-1){
                    temp = temp.next;
                    tempindex++;
                }
                newnode.next = temp.next;
                temp.next = newnode;
            }
            else{
                Node<T> temp = first;
                Node<T> newnode = new Node<T>(elem);
                int tempindex = 0;
                while(tempindex < index-1){
                    temp = temp.next;
                    tempindex++;
                }

                newnode.next = temp.next;
                temp.next = newnode;
            }

        }

    }
    public void add(T elem){
        Node<T> temp = new Node<T>(elem);

        if(first == null){
            first = temp;
        }
        else{
            Node<T> anothertemp = first;
            first = temp;
            first.next = anothertemp;
        }
    }
    public T remove(int index){
        if(index == 0){
            T vara = first.element;
            first = first.next;
            return vara;
        }
        else{
            Node<T> temp = first;
            int count = 0;
            List<T> createcopy = new ArrayList<>();
            createcopy.add(temp.element);
            while(count< index - 1){
                temp = temp.next;
                createcopy.add(temp.element);
                count++;
            }
            createcopy.add(temp.next.element);
            T vara = createcopy.get(createcopy.size()-1);
            //System.out.println(vara);
            Node<T> anothertemp = temp.next;
            temp.next = anothertemp.next;
            anothertemp.next = null;
            //System.out.println(vara);
            return vara;
        }

    }
    public void remove(T elem){
        Node<T> temp = first;
        if(first.element == elem){
            first = first.next;
        }
        else{
            Node<T> anothertemp = null;
            while(temp != null && temp.element != elem){
                anothertemp = temp;
                temp = temp.next;
            }
            if(temp == null) {
                throw new NoSuchElementException();
            }
            else{
                anothertemp.next = temp.next;
            }

        }


    }
    public boolean find(T elem){
        Node<T> temp = first;
        Node<T> anothertemp = null;
        while(temp != null && temp.element != elem){
            anothertemp = temp;
            temp = temp.next;
        }
        if(temp == null) {
            return false;
        }
        else{
            return true;
        }

    }
    /*public void printlinkedlist(){
        Node<T> temp = first;
        String combine = "";
        while(temp != null){
            combine = combine + temp.element.toString();
            //System.out.println(temp.element);
            temp = temp.next;
            combine += ",";
        }
        StringBuffer sb= new StringBuffer(combine);
        sb.deleteCharAt(sb.length()-1);
        System.out.println(sb);
    }*/

    /*public static void main(String[] args){
        CSE214List<String> emptylist = new SinglyLinkedList<>();
        CSE214List<String> strings = new SinglyLinkedList<>("a","b","c","d");
        System.out.println(strings.size());
        strings.add("e",500);
        strings.add("f",500);
        //strings.printlinkedlist();
        strings.remove("a");
        strings.remove("b");
        strings.remove("c");
        strings.remove("d");
        strings.remove("e");
        //strings.printlinkedlist();
        System.out.println(strings.size());
        System.out.println(strings.find("f"));
        System.out.println(strings.find("a"));

    }*/
}

package HW1;

import java.util.NoSuchElementException;

public class SinglyLinkedStack<T> implements CSE214Stack<T>{

    public CSE214List<T> singlyLinkedStack;

    public SinglyLinkedStack(){
        singlyLinkedStack = new SinglyLinkedList<>();

    }
    public SinglyLinkedStack(T ... element){
        singlyLinkedStack = new SinglyLinkedList<>(element);

    }

    public int size(){
        return singlyLinkedStack.size();
    }

    public T peek(){
        if(singlyLinkedStack.size() == 0){
            throw new NoSuchElementException();
        }
        T variable1 = singlyLinkedStack.remove(0);
        singlyLinkedStack.add(variable1);
        return variable1;
    }

    public T pop(){
        if(singlyLinkedStack.size() == 0){
            throw new NoSuchElementException();
        }
        return singlyLinkedStack.remove(0);
    }

    public void push(T elem){
        singlyLinkedStack.add(elem);
    }

    public boolean isEmpty(){
        if(singlyLinkedStack.size() == 0){
            return true;
        }
        return false;
    }
    /*public void printlist(){
        singlyLinkedStack.printlinkedlist();
    }*/

    /*public static void main(String[] args){
        CSE214Stack<String> variable1 = new SinglyLinkedStack<>("a","b");
        //variable1.printlist();
        variable1.push("c");
        //variable1.printlist();
        System.out.println(variable1.isEmpty());
        System.out.println(variable1.pop());
        System.out.println(variable1.peek());
        System.out.println(variable1.size());
        CSE214Stack<String> variable2 = new SinglyLinkedStack<>();
        System.out.println(variable2.size());
        //System.out.println(variable2.peek());
        //System.out.println(variable2.pop());
        variable2.push("a");
        System.out.println(variable2.peek());
        //variable2.printlist();
        System.out.println(variable2.size());

    }*/


}

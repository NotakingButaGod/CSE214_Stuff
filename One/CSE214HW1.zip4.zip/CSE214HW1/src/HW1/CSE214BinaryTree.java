package HW1;

import java.util.ArrayList;
import java.util.Arrays;

public class CSE214BinaryTree<T> implements CSE214Tree<T> {
    public static class TreeNode<T>{
        T val;
        TreeNode<T> left;
        TreeNode<T> right;
        TreeNode() {}
        TreeNode(T val) { this.val = val;}
        TreeNode(T val, TreeNode<T> left, TreeNode<T> right){
            this.val = val;
            this.left = left;
            this.right = right;
        }
    }
    TreeNode<T> root;

    ArrayList<T> tree;

    private String s = "";


    public CSE214BinaryTree(T ... element){
       tree = new ArrayList<T>(Arrays.asList(element));
       root = buildbinarytree(tree,root,0);
    }

    public TreeNode<T> buildbinarytree(ArrayList<T> input,TreeNode<T> root, int i){
        if(i < input.size()){
            TreeNode<T> temp = new TreeNode<>(input.get(i));
            root = temp;
            root.left = buildbinarytree(input,root.left,2*i+1);
            root.right = buildbinarytree(input,root.right,2*i+2);
        }
        return root;
    }
    public void prehelper(TreeNode<T> input){
        if(input != null){
            s += input.val.toString() + ", ";
            prehelper(input.left);
            prehelper(input.right);
        }
    }

    public String preorder(){
        s = "";
        prehelper(root);
        StringBuffer s1 = new StringBuffer(s);
        s1.deleteCharAt(s1.length()-2);
        s= "";
        s += s1;
        return s;
    }

    public void posthelper(TreeNode<T> input){
        if(input != null){
            posthelper(input.left);
            posthelper(input.right);
            s += input.val.toString() + ", ";
        }
    }
    public String postorder(){
        s = "";
        posthelper(root);
        StringBuffer s1 = new StringBuffer(s);
        s1.deleteCharAt(s1.length()-2);
        s= "";
        s += s1;
        return s;
    }

    public void inorderhelper(TreeNode<T> input){
        if(input != null){
            inorderhelper(input.left);
            //System.out.println(input.val);
            s += input.val.toString() + ", ";
            inorderhelper(input.right);
        }


    }
    public String inorder(){
        s = "";
        inorderhelper(root);
        StringBuffer s1 = new StringBuffer(s);
        s1.deleteCharAt(s1.length()-2);
        s= "";
        s += s1;
        //System.out.println(combine);
        return s;
    }
    public int counthelper(TreeNode<T> input){
        if(input != null){
            return 1 + counthelper(input.left) + counthelper(input.right);
        }
        return 0;
    }
    public int numNodes(){
        return counthelper(root);
    }


    public int depthhelper(TreeNode<T> input){
        if(input != null){
            int leftside = depthhelper(input.left);
            int rightside = depthhelper(input.right);
            return Math.max(leftside,rightside) + 1;
        }
        return 0;
    }
    public int depth(){

        return depthhelper(root);
    }

    /*public static void main(String[] args){
        CSE214Tree<String> variable1 = new CSE214BinaryTree<>("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p");
        System.out.println(variable1.inorder());
        System.out.println(variable1.preorder());
        System.out.println(variable1.postorder());
        System.out.println(variable1.numNodes());
        System.out.println(variable1.depth());
        //CSE214Tree<Integer> variable2 = new CSE214BinaryTree<>(1,2,3,4);
        //System.out.println(variable2.inorder());
    }*/


}

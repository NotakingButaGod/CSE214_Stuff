import com.sun.source.tree.Tree;

import javax.swing.tree.TreeNode;
import java.util.*;

public class Graph {
    private final double[][] adjacencyMatrix;
    private Graph(double[][] adjacencyMatrix) {
        this.adjacencyMatrix = adjacencyMatrix;
    }

    public static Graph fromMatrixString(String s) {
        String string1 = s;
        if(string1.compareTo("") == 0){
            System.out.println("empty string given");
            System.out.println("Exception in thread \"main\" java.lang.NullPointerException");
            return new Graph(new double[0][0]);
        }
        if(!string1.contains("\n")){
            double[][] local = new double[1][1];
            local[0][0] = Double.parseDouble(string1);
            System.out.println("one vertex");
            return new Graph(local);
        }
        String str[] = s.split("\n");
        int linelength = 0;
        if(!str[0].contains(" ")){
            linelength = 1;
        }
        else{
            linelength = str[0].split(" ").length;
        }
        //System.out.println(linelength);
        int rolllength = 0;
        for(int i = 0; i < str.length; i++){
            rolllength++;
        }
        double[][] local = new double[linelength][rolllength];
        for(int i = 0; i < str.length; i++){
            String str1[] = str[i].split(" "); // "0.0" "0.0" "0.5" "0.7" "0.0" "0.0"
            for(int j = 0; j < str1.length ; j++){
                local[i][j] = Double.parseDouble(str1[j]);
            }
        }
        return new Graph(local);
        /* TODO: */
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < adjacencyMatrix.length; i++) {
            for (int j = 0; j < adjacencyMatrix[i].length; j++) {
                builder.append(String.format("%1.2f ", adjacencyMatrix[i][j]));
            }
            builder.append("\n");
        }
        return builder.toString();
    }
    public ArrayList<String> search(double[][] temp, double edgeweight){
        ArrayList<String> finalresult = new ArrayList<>();

        for(int i = 0; i < temp.length ; i++){
            for(int j = 0; j < temp[i].length ; j++){
                if(temp[i][j] == edgeweight){
                    finalresult.add(i + " " + j);
                    return finalresult;
                }
            }
        }
        return finalresult;
    }


    public Graph getTree() {
        if(this.adjacencyMatrix.length == 0){
            System.out.println("empty graph given");
            System.out.println("Exception in thread \"main\" java.lang.NullPointerException");
            return new Graph(new double[0][0]);
        }
        if(this.adjacencyMatrix.length == 1){
            System.out.println("one vertex");
            return new Graph(this.adjacencyMatrix);
        }
        int root = 0; //starting index
        List<Integer> ss = new ArrayList<>();
        for(int i = 0; i < this.adjacencyMatrix.length ; i++){
            ss.add(i);
        }
        double[][] local = new double[ss.size()][ss.size()];
        for(int i = 0; i < local.length; i++){
            for(int j = 0; j < local[i].length; j++){
                local[i][j] = 0.0;
            }
        }

        double[][] temp = new double[ss.size()][ss.size()];
        for(int i = 0; i < this.adjacencyMatrix.length ; i++){
            for(int j = 0; j < this.adjacencyMatrix[i].length ; j++){
                temp[i][j] = this.adjacencyMatrix[i][j];
            }
        }
        int number = 0;
        ArrayList<Boolean> check = new ArrayList<>();
        Boolean checktwice = true;
        while(number < ss.size() - 1){
            List<Double> leasted = new ArrayList<>();
            for(int i = 0; i < temp.length; i++){ // the least edge weight connected to the index this case
                for(int j = 0; j < temp[i].length; j++){
                    if(temp[i][j]!= 0.0){
                        leasted.add(temp[i][j]);
                    }
                }
            }
            Collections.sort(leasted);
            //System.out.println(leasted);

            ArrayList<String> gonnabeused = search(temp,leasted.get(0));
            //System.out.println(gonnabeused);
            for(int i = 0; i < gonnabeused.size(); i++){
                int ii = Integer.parseInt(gonnabeused.get(i).split(" ")[0]);
                int jj = Integer.parseInt(gonnabeused.get(i).split(" ")[1]);
                for(int k = 0; i < local.length; i++){ // the least edge weight connected to the index this case
                    if(local[k][ii] > 0.0 && local[k][jj] > 0.0){
                        System.out.println("cycle");
                        temp[ii][jj] = 0.0;
                        temp[jj][ii] = 0.0;
                        break;
                    }
                    else{
                        local[ii][jj] = leasted.get(0);
                        local[jj][ii] = leasted.get(0);
                        //System.out.println(leasted.get(0));
                        temp[ii][jj] = 0.0;
                        temp[jj][ii] = 0.0;
                        number += 1;
                        break;

                    }
                }
            }
            //System.out.println(number);
        }
        return new Graph(local);
        //List<Double> store1 = new ArrayList<>();
        //List<String> store2 = new ArrayList<>();
        //List<Integer> store3 = new ArrayList<>();
        //Boolean getout = true;
        //List<Boolean> getout2 = new ArrayList<>();
        /*while(getout){
            int stepover = root;
            List<Double> edgeweight = new ArrayList<>();
            List<Integer> rollNline = new ArrayList<>();
            for(int i = 0; i < this.adjacencyMatrix[stepover].length ; i++){
                if(this.adjacencyMatrix[stepover][i] == 0.0){
                    local[stepover][i] = 0.0;
                }
                else if(this.adjacencyMatrix[stepover][i] > 0.0){
                    if(edgeweight.isEmpty() && rollNline.isEmpty()){
                        edgeweight.add(this.adjacencyMatrix[stepover][i]);
                        rollNline.add(stepover);
                        rollNline.add(i);

                    }
                    else{
                        if(store1.isEmpty() && store2.isEmpty()){
                            if(this.adjacencyMatrix[stepover][i] < edgeweight.get(0)){
                                edgeweight.remove(0);
                                rollNline.remove(0);
                                rollNline.remove(0);
                                edgeweight.add(this.adjacencyMatrix[stepover][i]);
                                rollNline.add(stepover);
                                rollNline.add(i);
                            }
                            else{
                                store1.add(this.adjacencyMatrix[stepover][i]);
                                store2.add(stepover + " " + i);
                            }
                        }
                        else if(!store1.isEmpty() && !store2.isEmpty()){
                            List<Double> edgeweight2 = new ArrayList<>();
                            List<Integer> rollNline2 = new ArrayList<>();
                            for(int k = 0; k < store1.size() ; k++){
                                if(edgeweight2.isEmpty() && rollNline2.isEmpty()){
                                    edgeweight2.add(store1.get(k));
                                    rollNline2.add(Integer.parseInt(store2.get(k).split(" ")[0]));
                                    rollNline2.add(Integer.parseInt(store2.get(k).split(" ")[1]));
                                    //System.out.println(edgeweight2);
                                    //ystem.out.println(rollNline2);
                                }
                                else{
                                    if(store1.get(k) < edgeweight2.get(0)){
                                        edgeweight2.remove(0);
                                        rollNline2.remove(0);
                                        rollNline2.remove(0);
                                        edgeweight2.add(store1.get(k));
                                        rollNline2.add(Integer.parseInt(store2.get(k).split(" ")[0]));
                                        rollNline2.add(Integer.parseInt(store2.get(k).split(" ")[1]));
                                        store1.remove(k);
                                        store2.remove(k);
                                    }
                                }
                            }
                            if(edgeweight2.get(0) < this.adjacencyMatrix[stepover][i] && edgeweight2.get(0) < edgeweight.get(0)){
                                if(!store3.contains(rollNline2.get(1))){
                                    edgeweight.remove(0);
                                    rollNline.remove(0);
                                    rollNline.remove(0);
                                    edgeweight.add(edgeweight2.get(0));
                                    rollNline.add(rollNline2.get(0));
                                    rollNline.add(rollNline2.get(1));
                                }
                                else{
                                    if(this.adjacencyMatrix[stepover][i] < edgeweight.get(0)){
                                        edgeweight.remove(0);
                                        rollNline.remove(0);
                                        rollNline.remove(0);
                                        edgeweight.add(this.adjacencyMatrix[stepover][i]);
                                        rollNline.add(stepover);
                                        rollNline.add(i);
                                    }
                                    store1.add(this.adjacencyMatrix[stepover][i]);
                                    store2.add(stepover + " " + i);
                                }

                            }
                            else if(edgeweight2.get(0) > this.adjacencyMatrix[stepover][i] && edgeweight2.get(0) < edgeweight.get(0)){
                                edgeweight.remove(0);
                                rollNline.remove(0);
                                rollNline.remove(0);
                                edgeweight.add(this.adjacencyMatrix[stepover][i]);
                                rollNline.add(stepover);
                                rollNline.add(i);
                            }
                            else{
                                store1.add(this.adjacencyMatrix[stepover][i]);
                                store2.add(stepover + " " + i);
                            }
                        }
                    }
                }
            }
            store3.add(rollNline.get(1));
            //System.out.println(store3);
            //System.out.println(ss);
            local[rollNline.get(0)][rollNline.get(1)] = edgeweight.get(0);
            System.out.println(new Graph(local));
            for(int p = 0; p < ss.size() ; p++){
                if(store3.contains(ss.get(p))){
                    getout2.add(true);
                }
                else{
                    getout2.add(false);
                }
            }
            if(!getout2.contains(false)){
                getout = false;
            }
            System.out.println(getout2);
            getout2.clear();
            System.out.println(getout2);
            if(root < adjacencyMatrix.length - 1){
                root++;
            }

        }*/
        /* TODO: */
    }

    private static final String s =
                    "0.0 0.0 0.5 0.7 0.0 0.0\n" +
                    "0.0 0.0 0.7 0.0 1.0 0.0\n" +
                    "0.5 0.7 0.0 1.0 0.0 0.9\n" +
                    "0.7 0.0 1.0 0.0 0.0 0.0\n" +
                    "0.0 1.0 0.0 0.0 0.0 0.7\n" +
                    "0.0 0.0 0.9 0.0 0.7 0.0";
    private static final String s1 = "";

    private static final String s2 = "0.0";

    private static final String s3 = "0.2";

    private static final String s4 = "0.0 0.5 0.5 0.8\n" + "0.5 0.0 0.6 0.0\n" + "0.5 0.6 0.0 0.7\n" + "0.8 0.0 0.7 0.0";

    private static final String s5 =
            "0.0 0.6 0.5 0.5 0.8\n" +
            "0.6 0.0 0.4 0.7 0.4\n" +
            "0.5 0.4 0.0 0.8 0.6\n" +
            "0.5 0.7 0.8 0.0 0.3\n" +
            "0.8 0.4 0.6 0.3 0.0";

    public static void main(String... args) {
        // you can assume that incorrect strings will not be provided as input,
        // i.e., any input string will be a valid adjacency matrix
        // representation of an undirected weighted graph
        Graph g = Graph.fromMatrixString(s);
        System.out.println(g);
        System.out.println(g.getTree());
        //System.out.println(g);

        Graph g1 = Graph.fromMatrixString(s1);
        System.out.println(g1);
        System.out.println(g1.getTree());

        //Graph g2 = Graph.fromMatrixString(s3);
        //System.out.println(g2);
        //System.out.println(g2.getTree());

        //Graph g3 = Graph.fromMatrixString(s4);
        //System.out.println(g3);
        //System.out.println(g3.getTree());

        Graph g5 = Graph.fromMatrixString(s5);
        System.out.println(g5);
        System.out.println(g5.getTree());

    }

}



public interface Evaluator {

    double evaluate(String expressionString);

}

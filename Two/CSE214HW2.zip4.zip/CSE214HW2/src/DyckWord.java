import java.util.ArrayList;
import java.util.List;

/**
 * @author Ritwik Banerjee
 */
public class DyckWord {
    
    private final String word;
    
    public DyckWord(String word) {
        if (isDyckWord(word))
            this.word = word;
        else
            throw new IllegalArgumentException(String.format("%s is not a valid Dyck word.", word));
    }
    
    private static boolean isDyckWord(String word) {
        char[] stringarray = word.toCharArray();
        List<String> emptylist = new ArrayList<>();
        int numofleft = 0;
        int numofright = 0;
        String wordcopy = "";
        String left = "(";
        String right = ")";
        for(char i : stringarray ){
            emptylist.add(String.valueOf(i));
        }
        for(int i = 0; i < emptylist.size(); i++){
            if(left.compareTo(emptylist.get(i)) == 0){
                wordcopy += "(";
                numofleft += 1;
            }
            if(right.compareTo(emptylist.get(i)) == 0){
                wordcopy += ")";
                numofright += 1;
            }
            if(wordcopy.compareTo(")(") == 0){
                return false;
            }
            if(wordcopy.length() == 2){
                wordcopy = "";
            }
        }
        return numofleft == numofright;// todo. currently a placeholder return value "false" is kept.
    }
    
    public String getWord() {
        return word;
    }
    public static void main(String[] args) {
        System.out.println(isDyckWord("()()"));
    }
    
}

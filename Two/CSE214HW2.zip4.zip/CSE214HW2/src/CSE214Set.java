public interface CSE214Set<E> {



    int size();
    boolean contains(Object o);
    boolean add(E e);

}

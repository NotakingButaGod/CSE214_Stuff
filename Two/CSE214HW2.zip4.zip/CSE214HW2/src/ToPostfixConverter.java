
import java.util.Stack;

public class ToPostfixConverter implements Converter{

    public String nextToken(String s, int start){
        return "";
    }

    public boolean isOperand(String s){
        return false;
    }
    public String convert(ArithmeticExpression expression){
        Stack<String> emptystack = new Stack<>();
        String input1 = expression.getExpression();
        String output = "";
        for(int i = 0; i < input1.length(); i++){
            char strtochar = input1.charAt(i);

            if(Character.toString(strtochar).compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) == 0 ){
                emptystack.push(Character.toString(strtochar));

            }
            else if(Character.toString(strtochar).compareTo(Character.toString(Operator.RIGHT_PARENTHESIS.getSymbol())) == 0){
                while(emptystack.peek().compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) != 0){
                    String value = emptystack.pop();
                    output += " " + (value) + " ";
                }
                emptystack.pop();
            }
            else if(Character.toString(strtochar).compareTo(Character.toString(Operator.ADDITION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.DIVISION.getSymbol())) == 0) {
                output += " ";
                if(emptystack.isEmpty() || emptystack.peek().compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) == 0){
                    emptystack.push(Character.toString(strtochar));
                }
                else if(!emptystack.isEmpty() || emptystack.peek().compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) == 0){
                    int rankofinput = 0;
                    int rankoftopstack = 0;
                    if(Character.toString(strtochar).compareTo(Character.toString(Operator.ADDITION.getSymbol())) == 0){
                        rankofinput = Operator.ADDITION.getRank();
                    }
                    else if(Character.toString(strtochar).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) == 0){
                        rankofinput = Operator.SUBTRACTION.getRank();
                    }
                    else if(Character.toString(strtochar).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) == 0){
                        rankofinput = Operator.MULTIPLICATION.getRank();
                    }
                    else if(Character.toString(strtochar).compareTo(Character.toString(Operator.DIVISION.getSymbol())) == 0){
                        rankofinput = Operator.DIVISION.getRank();
                    }

                    if(emptystack.peek().compareTo(Character.toString(Operator.ADDITION.getSymbol())) == 0){
                        rankoftopstack = Operator.ADDITION.getRank();
                    }
                    else if(emptystack.peek().compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) == 0){
                        rankoftopstack = Operator.SUBTRACTION.getRank();
                    }
                    else if(emptystack.peek().compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) == 0){
                        rankoftopstack = Operator.MULTIPLICATION.getRank();
                    }
                    else if(emptystack.peek().compareTo(Character.toString(Operator.DIVISION.getSymbol())) == 0){
                        rankoftopstack = Operator.DIVISION.getRank();
                    }

                    if(rankofinput < rankoftopstack){
                        emptystack.push(Character.toString(strtochar));
                    }
                    else if(rankofinput == rankoftopstack){
                        String value = emptystack.pop();
                        output += " " + (value) + " ";
                        emptystack.push(Character.toString(strtochar));
                    }
                    else if(rankofinput > rankoftopstack){
                        if(!emptystack.contains(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol()))){
                            while(!emptystack.isEmpty()){
                                String value = emptystack.pop();
                                output += " " + (value) + " ";
                            }

                        }
                        else{
                            while(emptystack.peek().compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) != 0) {
                                String value = emptystack.pop();
                                output += " " + (value) + " ";
                            }

                        }
                        emptystack.push(Character.toString(strtochar));
                    }


                }

            }
            else{
                if(i == 0){
                    output += Character.toString(strtochar) ;
                }
                else if( i > 0){
                    if(Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.ADDITION.getSymbol())) != 0 &&
                            Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) != 0 &&
                            Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) != 0 &&
                            Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.DIVISION.getSymbol())) != 0 &&
                            Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) != 0 &&
                            Character.toString(input1.charAt(i - 1)).compareTo(Character.toString(Operator.RIGHT_PARENTHESIS.getSymbol())) != 0 ){
                        output += Character.toString(strtochar) ;
                        //System.out.println(output);

                    }
                    else if(i < input1.length() - 1){
                        if(Character.toString(input1.charAt(i+1)).compareTo(Character.toString(Operator.ADDITION.getSymbol())) != 0 &&
                                Character.toString(input1.charAt(i+1)).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) != 0 &&
                                Character.toString(input1.charAt(i + 1)).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) != 0 &&
                                Character.toString(input1.charAt(i + 1)).compareTo(Character.toString(Operator.DIVISION.getSymbol())) != 0 &&
                                Character.toString(input1.charAt(i + 1)).compareTo(Character.toString(Operator.LEFT_PARENTHESIS.getSymbol())) != 0 &&
                                Character.toString(input1.charAt(i + 1)).compareTo(Character.toString(Operator.RIGHT_PARENTHESIS.getSymbol())) != 0){
                            output += Character.toString(strtochar) ;
                        }
                        else{
                            output += Character.toString(strtochar) ;
                            output += " ";
                        }
                    }
                    else{
                        output += Character.toString(strtochar) ;
                        output += " ";
                    }
                }
            }

        }
        while(!emptystack.isEmpty()){
            String value = emptystack.pop();
            output += " " + (value) + " ";
        }

        while(output.contains("  ")){
            output = output.replaceAll("  "," ");
        }
        output = output.replaceAll(" \\. ",".");
        return output;
    }

    /*public static void main(String... args){
        ArithmeticExpression SD = new ArithmeticExpression("22   *((5.5+356)   /25.3)");
        Converter SDS = new ToPostfixConverter();

        System.out.println(SDS.convert(SD));
    }*/



}

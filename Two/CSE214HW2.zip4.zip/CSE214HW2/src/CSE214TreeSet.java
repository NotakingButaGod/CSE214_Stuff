import java.util.Comparator;


public class CSE214TreeSet<E extends Comparable<E>> extends BinaryTree<E> implements CSE214Set<E>{
    private int count1 = 0;

    private E value;
    private boolean color; // red is true, black is false
    private CSE214TreeSet<E> leftchild;
    private CSE214TreeSet<E> rightchild;
    private CSE214TreeSet<E> parent;

    private CSE214TreeSet<E> treecreated;
    private CSE214TreeSet<E> root = this;
    public CSE214TreeSet(){

    }
    public CSE214TreeSet(E value){
        count1+= 1;
        this.value = value;
        this.color = true;
    }
    public E getValue() {
        return value;
    }

    public void setValue(E value) {
        this.value = value;
    }

    public boolean isColor() {
        return color;
    }

    public void setColor(boolean color) {
        this.color = color;
    }

    public CSE214TreeSet<E> getLeftchild() {
        return leftchild;
    }

    public void setLeftchild(CSE214TreeSet<E> leftchild) {
        this.leftchild = leftchild;
    }

    public CSE214TreeSet<E> getRightchild() {
        return rightchild;
    }

    public void setRightchild(CSE214TreeSet<E> rightchild) {
        this.rightchild = rightchild;
    }

    public CSE214TreeSet<E> getParent() {
        return parent;
    }

    public void setParent(CSE214TreeSet<E> parent) {
        this.parent = parent;
    }

    private void rotateRight(CSE214TreeSet<E> node) {
        CSE214TreeSet<E> parent = node.parent;
        CSE214TreeSet<E> leftChild = node.leftchild;

        node.leftchild = leftChild.rightchild;
        if (leftChild.rightchild != null) {
            leftChild.rightchild.parent = node;
        }

        leftChild.rightchild = node;
        node.parent = leftChild;

        replaceParentsChild(parent, node, leftChild);
    }
    private void replaceParentsChild(CSE214TreeSet<E> parent, CSE214TreeSet<E> oldChild, CSE214TreeSet<E> newChild) {
        if (parent == null) {
            root = newChild;
        } else if (parent.leftchild == oldChild) {
            parent.leftchild = newChild;
        } else if (parent.rightchild == oldChild) {
            parent.rightchild = newChild;
        } else {
            throw new IllegalStateException("Node is not a child of its parent");
        }

        if (newChild != null) {
            newChild.parent = parent;
        }
    }
    private void rotateLeft(CSE214TreeSet<E> node) {
        CSE214TreeSet<E> parent = node.parent;
        CSE214TreeSet<E> rightChild = node.rightchild;

        node.rightchild = rightChild.leftchild;
        if (rightChild.leftchild != null) {
            rightChild.leftchild.parent = node;
        }

        rightChild.leftchild = node;
        node.parent = rightChild;

        replaceParentsChild(parent, node, rightChild);
    }

    public void insertNode(E e) {
            count1+= 1;
            CSE214TreeSet<E> node = root;
            CSE214TreeSet<E> parent = null;
            if(node.value == null){
                node.value = e;
            }
            // Traverse the tree to the left or right depending on the key
            while (node != null) {
                parent = node;
                if (e.compareTo(node.getValue()) < 0) {
                    node = node.leftchild;
                }
                else if (e.compareTo(node.getValue()) > 0) {
                    node = node.rightchild;
                } else {
                    return ;
                }
            }
            // Insert new node
            CSE214TreeSet<E> newNode = new CSE214TreeSet<>(e);
            newNode.color = true;
            if (parent == null) {
                root = newNode;
            } else if (e.compareTo(parent.getValue()) < 0) {
                parent.leftchild = newNode;
            } else {
                parent.rightchild = newNode;
            }
            newNode.parent = parent;
            fixRedBlackPropertiesAfterInsert(newNode);

    }
    private void fixRedBlackPropertiesAfterInsert(CSE214TreeSet<E> node) {
        CSE214TreeSet<E> parent = node.parent;

        // Case 1: Parent is null, we've reached the root, the end of the recursion
        if (parent == null) {
            // Uncomment the following line if you want to enforce black roots (rule 2):
            // node.color = BLACK;
            return;
        }

        // Parent is black --> nothing to do
        if (parent.color == false) {
            return;
        }

        // From here on, parent is red
        CSE214TreeSet<E> grandparent = parent.parent;

        // Case 2:
        // Not having a grandparent means that parent is the root. If we enforce black roots
        // (rule 2), grandparent will never be null, and the following if-then block can be
        // removed.
        if (grandparent == null) {
            // As this method is only called on red nodes (either on newly inserted ones - or -
            // recursively on red grandparents), all we have to do is to recolor the root black.
            parent.color = false;
            return;
        }

        // Get the uncle (may be null/nil, in which case its color is BLACK)
        CSE214TreeSet uncle = getUncle(parent);

        // Case 3: Uncle is red -> recolor parent, grandparent and uncle
        if (uncle != null && uncle.color == true) {
            parent.color = false;
            grandparent.color = true;
            uncle.color = false;

            // Call recursively for grandparent, which is now red.
            // It might be root or have a red parent, in which case we need to fix more...
            fixRedBlackPropertiesAfterInsert(grandparent);
        }

        // Parent is left child of grandparent
        else if (parent == grandparent.leftchild) {
            // Case 4a: Uncle is black and node is left->right "inner child" of its grandparent
            if (node == parent.rightchild) {
                rotateLeft(parent);

                // Let "parent" point to the new root node of the rotated sub-tree.
                // It will be recolored in the next step, which we're going to fall-through to.
                parent = node;
            }

            // Case 5a: Uncle is black and node is left->left "outer child" of its grandparent
            rotateRight(grandparent);

            // Recolor original parent and grandparent
            parent.color = false;
            grandparent.color = true;
        }

        // Parent is right child of grandparent
        else {
            // Case 4b: Uncle is black and node is right->left "inner child" of its grandparent
            if (node == parent.leftchild) {
                rotateRight(parent);

                // Let "parent" point to the new root node of the rotated sub-tree.
                // It will be recolored in the next step, which we're going to fall-through to.
                parent = node;
            }

            // Case 5b: Uncle is black and node is right->right "outer child" of its grandparent
            rotateLeft(grandparent);

            // Recolor original parent and grandparent
            parent.color = false;
            grandparent.color = true;
        }//System.out.println(root.toString());
    }
    private CSE214TreeSet<E> getUncle(CSE214TreeSet<E> parent) {
        CSE214TreeSet<E> grandparent = parent.parent;
        if (grandparent.leftchild == parent) {
            return grandparent.rightchild;
        } else if (grandparent.rightchild == parent) {
            return grandparent.leftchild;
        } else {
            return null;
        }
    }

    public String toString() {
        return traversePreOrder1(this.root);
    }

    public int size(){
        return count1;
    }
    public boolean contains(Object o){
        E that = (E) o;
        CSE214TreeSet<E> node = root;
        if(node.value == null){
            return false;
        }
        while (node != null) {
            if (that == node.getValue()) {
                return true;
            } else if (that.compareTo(node.getValue()) < 0) {
                node = node.leftchild;
            } else {
                node = node.rightchild;
            }
        }
        return false;
 // similarly for left and right
    }
    public boolean add(E e){
        boolean check = this.root.contains(e);
        if(check == false){
            this.root.insertNode(e);
            return true;
        }
        return false;
    }
    private static <E extends Comparable<E>> String traversePreOrder1(CSE214TreeSet<E> root) {
        if (root == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        sb.append(root.getValue());

        String pointerRight = "└──";
        String pointerLeft  = (root.getRight() != null) ? "├──" : "└──";

        traverseNodes1(sb, "", pointerLeft, root.getLeftchild(), root.getRightchild() != null);
        traverseNodes1(sb, "", pointerRight, root.getRightchild(), false);

        return sb.toString();
    }
    private static <E extends Comparable<E>> void traverseNodes1(StringBuilder sb, String padding, String pointer, CSE214TreeSet<E> node, boolean hasRightSibling) {
        if (node != null) {
            sb.append("\n");
            sb.append(padding);
            sb.append(pointer);
            sb.append(node.getValue());
            sb.append(" [").append(node.color).append("]");

            StringBuilder paddingBuilder = new StringBuilder(padding);
            if (hasRightSibling) {
                paddingBuilder.append("│  ");
            } else {
                paddingBuilder.append("   ");
            }

            String paddingForBoth = paddingBuilder.toString();
            String pointerRight   = "└──";
            String pointerLeft    = (node.getRight() != null) ? "├──" : "└──";

            traverseNodes1(sb, paddingForBoth, pointerLeft, node.getLeftchild(), node.getRightchild() != null);
            traverseNodes1(sb, paddingForBoth, pointerRight, node.getRightchild(), false);
        }
    }
    public static void main(String[] args) {
        CSE214TreeSet<Integer> REDBLACKTREE = new CSE214TreeSet<>();
        REDBLACKTREE.add(10);
        System.out.println(REDBLACKTREE.add(10));

        System.out.println(REDBLACKTREE.size());
        System.out.println(REDBLACKTREE.toString());

        //CSE214TreeSet<Integer> REDBLACKTREE2 = new CSE214TreeSet<>(1);
        //System.out.println(REDBLACKTREE2.size());
        //System.out.println(REDBLACKTREE2.toString());
    }
}

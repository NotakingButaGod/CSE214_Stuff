import java.util.Stack;

public class PostfixEvaluator implements  Evaluator{
    public double evaluate(String expressionString){
        Stack<Double> emptystack = new Stack<>();
        String s = "";
        for(int i = 0; i < expressionString.length(); i++){


            char strtochar = expressionString.charAt(i);
            System.out.println(strtochar);
            if(Character.toString(strtochar).compareTo(Character.toString(Operator.ADDITION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) == 0 ||
                    Character.toString(strtochar).compareTo(Character.toString(Operator.DIVISION.getSymbol())) == 0){
                double num1 = emptystack.pop();
                double num2 = emptystack.pop();

                if(Character.toString(strtochar).compareTo(Character.toString(Operator.ADDITION.getSymbol())) == 0){
                    double num3 = num1 + num2;
                    emptystack.push(num3);
                }
                else if(Character.toString(strtochar).compareTo(Character.toString(Operator.MULTIPLICATION.getSymbol())) == 0){
                    double num3 = num1 * num2;
                    emptystack.push(num3);
                }
                else if(Character.toString(strtochar).compareTo(Character.toString(Operator.SUBTRACTION.getSymbol())) == 0){
                    double num3 = num2 - num1;
                    emptystack.push(num3);
                }
                else if(Character.toString(strtochar).compareTo(Character.toString(Operator.DIVISION.getSymbol())) == 0){
                    double num3 = num2 / num1;
                    emptystack.push(num3);
                }


            }
            else if(Character.toString(expressionString.charAt(i+1)).compareTo(" ") != 0){
                    s += Character.toString(expressionString.charAt(i));


            }
            else if(Character.toString(expressionString.charAt(i+1)).compareTo(" ") == 0){
                s+= Character.toString(expressionString.charAt(i));
                emptystack.push(Double.parseDouble(s));
                s = "";
            }

        }

        return Math.round(emptystack.pop() * 100.0) / 100.0; // round up to the two decimal places
    }

    /*public static void main(String... args){
        String s = "22 5.5 356 + 25.3 / *";
        System.out.println(new PostfixEvaluator().evaluate(s));
    }*/
}
